/*
* TP 1 - Premiers pas en CUDA
* --------------------------
* Ex 1 : Verifions le matériel
*
* File: deviceProperties.hpp
* Author: Maxime MARIA
*/

#ifndef __DEVICE_PROPERTIES_HPP
#define __DEVICE_PROPERTIES_HPP

int countDevices();

void printDeviceProperties( const int i );

#endif



